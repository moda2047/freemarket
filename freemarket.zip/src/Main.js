import React from "react";
import Login from "./Login/Login.js";

const Main = (props) => {
  return (
    <div className="mainWrap">
      <Login />
    </div>
  );
};

export default Main;
