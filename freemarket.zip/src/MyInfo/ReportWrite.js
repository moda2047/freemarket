import React, { useState } from "react";
import "./ReportWrite.css";

function ReportWrite() {
  const [title, setTitle] = useState("");
  const [content, setContent] = useState("");

  // 데이터를 저장하는 함수
  const saveData = () => {
    console.log("제목:", title);
    console.log("내용:", content);
  };

  return (
    <div className="MyReportMSListWrap">
      <div className="MyReportMSListWrapDiv">
        <h3>
          <img src="./image/MyInfoReviewIwImg.png" alt="nono" />
        </h3>
      </div>
      <hr />
      <div className="MyReportWriteContainer">
        <h2>신고글 작성</h2>
        <div>
          <label htmlFor="title">제목 : </label>
          <input
            className="MyReportWriteInput"
            type="text"
            id="title"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
          />
        </div>
        <div>
          <label className="MyReportWriteLabel" htmlFor="content">
            내용:
          </label>
          <textarea
            className="MyReportWriteTextarea"
            id="content"
            value={content}
            onChange={(e) => setContent(e.target.value)}
          />
        </div>
        <button className="MyReportWriteSubmit-Button" onClick={saveData}>
          저장
        </button>
      </div>
    </div>
  );
}

export default ReportWrite;
