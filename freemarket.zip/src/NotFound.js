import React from "react";

const NotFound = () => {
  return <div style>404 Error</div>;
};

export default NotFound;
